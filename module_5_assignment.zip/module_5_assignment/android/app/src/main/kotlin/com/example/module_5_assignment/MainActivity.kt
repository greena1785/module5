package com.example.module_5_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
