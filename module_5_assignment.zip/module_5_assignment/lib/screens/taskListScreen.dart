import 'package:flutter/material.dart';
import 'package:module_5_assignment/model/task.dart';
import 'package:module_5_assignment/screens/taskScreen.dart';

import '../dbHelper/dbhelper.dart';


class MyTaskListPage extends StatefulWidget {
  const MyTaskListPage({super.key});

  @override
  State<MyTaskListPage> createState() => _MyTaskListPageState();
}

class _MyTaskListPageState extends State<MyTaskListPage> {
  List<Task> taskList = [];
  var dbHelper = DbHelper();

  void initState() {
    fetchTaskList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Person List Screen'),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () async{
            Task? person = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => TaskFormScreen(null),
                )
            );
            if(person != null){
              taskList.insert(0, person);
              refreshList(taskList);
            }
          },
          child: Icon(Icons.add),
        ),
        body: ListView.builder(
          itemCount: taskList.length,
          itemBuilder: (context, index){
            return Card(
              elevation: 2,
              shape:  RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              child: ListTile(
                onTap: () async{
                  Task? person = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TaskFormScreen(taskList[index]),
                    ),);
                  if (person != null) {
                    var index = taskList.indexWhere((element) => element.id == person.id);
                    taskList[index] = person;
                    refreshList(taskList);
                  }
                },
                title: Text('${taskList[index].name}',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                subtitle: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('${taskList[index].description}'),
                    Text('${taskList[index].date}'),
                    Text('${taskList[index].time}'),
                    Text('${taskList[index].priority}'),
                  ],
                ),
                trailing: IconButton(
                  onPressed: (){
                    var task = taskList[index];
                    deleteRecord(task);
                  },
                  icon: Icon(Icons.delete),
                  ),
              ),
            );
          },
        )
    );
  }
  Future<void> fetchTaskList() async {
    var categories = await dbHelper.getTask();
    refreshList(categories);
  }

  void refreshList(List<Task> tasks) {
    setState(() {
      taskList = tasks;
    });
  }

  Future<void> deleteRecord(Task task) async {
    var id = await dbHelper.deleteTask(task.id!);
    if (id == 1) {
      taskList.removeWhere((element) => element.id == task.id);
      refreshList(taskList);
    }
  }
}
